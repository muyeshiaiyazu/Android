
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;

@WebServlet(name = "/Test")
public class Test extends HttpServlet {
    private  String loginResult=new String();
    private  String registerResult=new String();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("进入服务器");
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();

        File userAccounts= new File("userAccounts.txt");
        if(!userAccounts.exists()){
            userAccounts.createNewFile();
        }
        RandomAccessFile raf = new RandomAccessFile(userAccounts,"rw");

        req.setCharacterEncoding("UTF-8");
        String requestType = req.getParameter("requestType");
        String userName=req.getParameter("userName");
        String password=req.getParameter("password");

        if(requestType.equals("register")){
            String status=req.getParameter("status");

            if(userAccounts.length()>0){
                raf.seek(0);
                String currentUserName = raf.readUTF();
                raf.readUTF();
                raf.readUTF();
                boolean hasRepeated = false;
                while(currentUserName!=null){
                    if(currentUserName.equals(userName)){
                        hasRepeated = true;
                        break;
                    }
                    if(raf.getFilePointer()<raf.length()){
                        currentUserName = raf.readUTF();
                        raf.readUTF();
                        raf.readUTF();
                    }else{
                        break;
                    }
                }
                if(hasRepeated){
                    registerResult = "failed";
                }else{
                    raf.seek(raf.length());
                    raf.writeUTF(userName);
                    raf.writeUTF(password);
                    raf.writeUTF(status);

                    registerResult = "successful";
                }
            }else{
                raf.seek(raf.length());
                raf.writeUTF(userName);
                raf.writeUTF(password);
                raf.writeUTF(status);

                registerResult = "successful";
            }
            raf.close();
            out.print(registerResult);
        }else if(requestType.equals("login")){

            if(userAccounts.length()!=0){
                raf.seek(0);
                String currentUserName = raf.readUTF();
                String currentPassword = raf.readUTF();
                String currentStatus = raf.readUTF();
                while(currentUserName!=null){
                    if(currentUserName.equals(userName)&&currentPassword.equals(password)){
                        loginResult = currentStatus;
                        break;
                    }
                    currentUserName = raf.readUTF();
                    currentPassword = raf.readUTF();
                    currentStatus = raf.readUTF();
                }
                raf.close();
            }else{
                loginResult = "failed";
            }

            out.print(loginResult);
        }

    }

}