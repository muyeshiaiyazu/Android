
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;

@WebServlet(name = "/Test")
public class Test extends HttpServlet {
    private String loginResult = new String();
    private String registerResult = new String();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String isDownload = request.getHeader("requestType");

        if (isDownload.equals("download")) {
            int BUFFER_SIZE = 1024 * 1024 * 10;
            String downloadUrl = "C:\\Users\\phw\\GymService\\gymVideos\\";

            request.setCharacterEncoding("utf-8");
            response.setCharacterEncoding("utf-8");
            response.setContentType("application/octet-stream");

            String fileName = request.getHeader("fileName");


            //可以根据传递来的userName和passwd做进一步处理，比如验证请求是否合法等
            File file = new File(downloadUrl + "a.txt");
            switch (fileName) {
                case "1":
                    file = new File(downloadUrl + "1.mp4");
                    break;
                case "2":
                    file = new File(downloadUrl + "2.mp4");
                    break;
                case "3":
                    file = new File(downloadUrl + "3.mp4");
                    break;
                case "4":
                    file = new File(downloadUrl + "4.mp4");
                    break;
                case "5":
                    file = new File(downloadUrl + "5.mp4");
                    break;
                case "6":
                    file = new File(downloadUrl + "6.mp4");
                    break;
            }
            response.setContentLength((int) file.length());
            response.setHeader("Accept-Ranges", "bytes");

            int readLength = 0;

            InputStream in = new BufferedInputStream(new FileInputStream(file), BUFFER_SIZE);
            OutputStream os = new BufferedOutputStream(response.getOutputStream());

            byte[] buffer = new byte[BUFFER_SIZE];
            while ((readLength = in.read(buffer)) > 0) {
                byte[] bytes = new byte[readLength];
                System.arraycopy(buffer, 0, bytes, 0, readLength);
                os.write(bytes);
            }
            os.flush();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("进入服务器");
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        File userAccounts = new File("userAccounts.txt");
        if (!userAccounts.exists()) {
            userAccounts.createNewFile();
        }
        RandomAccessFile raf = new RandomAccessFile(userAccounts, "rw");

        request.setCharacterEncoding("UTF-8");
        String requestType = request.getParameter("requestType");

        if (requestType.equals("register")) {
            String userName = request.getParameter("userName");
            String password = request.getParameter("password");
            String status = request.getParameter("status");

            if (userAccounts.length() > 0) {
                raf.seek(0);
                String currentUserName = raf.readUTF();
                raf.readUTF();
                raf.readUTF();
                boolean hasRepeated = false;
                while (currentUserName != null) {
                    if (currentUserName.equals(userName)) {
                        hasRepeated = true;
                        break;
                    }
                    if (raf.getFilePointer() < raf.length()) {
                        currentUserName = raf.readUTF();
                        raf.readUTF();
                        raf.readUTF();
                    } else {
                        break;
                    }
                }
                if (hasRepeated) {
                    registerResult = "failed";
                } else {
                    raf.seek(raf.length());
                    raf.writeUTF(userName);
                    raf.writeUTF(password);
                    raf.writeUTF(status);

                    registerResult = "successful";
                }
            } else {
                raf.seek(raf.length());
                raf.writeUTF(userName);
                raf.writeUTF(password);
                raf.writeUTF(status);

                registerResult = "successful";
            }
            raf.close();
            out.print(registerResult);
        } else if (requestType.equals("login")) {
            String userName = request.getParameter("userName");
            String password = request.getParameter("password");

            if (userAccounts.length() != 0) {
                raf.seek(0);
                String currentUserName = raf.readUTF();
                String currentPassword = raf.readUTF();
                String currentStatus = raf.readUTF();
                while (currentUserName != null) {
                    if (currentUserName.equals(userName) && currentPassword.equals(password)) {
                        loginResult = currentStatus;
                        break;
                    }
                    currentUserName = raf.readUTF();
                    currentPassword = raf.readUTF();
                    currentStatus = raf.readUTF();
                }
                raf.close();
            } else {
                loginResult = "failed";
            }

            out.print(loginResult);
        }
    }
}