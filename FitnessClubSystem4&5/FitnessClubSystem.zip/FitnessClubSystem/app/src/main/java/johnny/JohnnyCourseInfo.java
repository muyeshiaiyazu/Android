package johnny;


import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.example.phw.fitnessclubsystem.R;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import object.*;

public class JohnnyCourseInfo extends AppCompatActivity implements View.OnClickListener {
    private ImageView back;
    private Button playVideo;
    private VideoView videoView;
    private TextView phoneView;
    private Dialog dialog;

    private int COMPLETED = 0;
    private Uri uri = null;

    private Course course;

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == COMPLETED) {
                videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                    @Override
                    public void onPrepared(MediaPlayer mp) {
                        // TODO Auto-generated method stub
                        //  mTextView01.setText(strVideoPath);
                        setTitle(uri.toString());
                    }
                });
            }
            /* 设置控制Bar，显示在Context中*/
//            videoView.setMediaController(new MediaController(Member_Course_Info.this));
            videoView.requestFocus();
            //设置视频路径
            videoView.setVideoURI(uri);
            //开始播放视频
            videoView.start();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.johnny_course_info);
        View decorView = getWindow().getDecorView();
        int option = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(option);

        course = (Course)getIntent().getSerializableExtra("course");

        back = (ImageView) findViewById(R.id.img_back);
        playVideo = (Button) findViewById(R.id.button_play_video);
        phoneView = (TextView) findViewById(R.id.text_course_phone);
        videoView = (VideoView) findViewById(R.id.videoView);//设置视频播放器，准备函数
        TextView courseName = (TextView) findViewById(R.id.text_course_name);
        TextView johnnyName = (TextView) findViewById(R.id.text_instructor_name);
        TextView courseContent = (TextView) findViewById(R.id.text_course_content);
        TextView courseTime = (TextView) findViewById(R.id.text_time_info);
        TextView coursePrice = (TextView)findViewById(R.id.text_course_pay);

        phoneView.setTextColor(Color.parseColor("#5173B5"));
        SpannableString content = new SpannableString(phoneView.getText());//给电话号码设置下划线
        content.setSpan(new UnderlineSpan(), 0, phoneView.getText().length(), 0);
        phoneView.setText(content);

        courseName.setText(course.getName());
        johnnyName.setText(course.getJohnny());
        courseContent.setText(course.getContent());
        courseTime.setText(course.getTime());
        coursePrice.setText(course.getPrice());
        phoneView.setText(course.getJohnnyPhone());

        phoneView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                show();
            }
        });
        back.setOnClickListener(this);
        playVideo.setOnClickListener(this);
//        videoView.setOnTouchListener(this);
    }

    public void show() {
        dialog = new Dialog(this, R.style.ActionSheetDialogStyle);
        //填充对话框的布局
        View inflate = LayoutInflater.from(this).inflate(R.layout.contact_dialog, null);
        //初始化控件
        inflate.findViewById(R.id.button_dialog_call).setOnClickListener(this);
        inflate.findViewById(R.id.button_dialog_message).setOnClickListener(this);
        inflate.findViewById(R.id.button_dialog_cancel).setOnClickListener(this);
        //将布局设置给Dialog
        dialog.setContentView(inflate);
        //获取当前Activity所在的窗体
        Window dialogWindow = dialog.getWindow();
        if (dialogWindow == null) {
            return;
        }
        //设置Dialog从窗体底部弹出
        dialogWindow.setGravity(Gravity.BOTTOM);
        //获得窗体的属性
        WindowManager.LayoutParams lp = dialogWindow.getAttributes();
        lp.y = 20;//设置Dialog距离底部的距离
        //将属性设置给窗体
        dialogWindow.setAttributes(lp);
        dialog.show();//显示对话框
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button_play_video:
                Toast.makeText(JohnnyCourseInfo.this, "视频加载中...", Toast.LENGTH_LONG).show();
                new Thread(new Runnable() {
                    String fileName = "2";
                    String string_url = "http://192.168.0.110:8080/myGymService/mytest";

                    @Override
                    public void run() {
                        sendData();
                    }

                    public void sendData() {
                        try {
                            HttpGet httpGet = new HttpGet(string_url);
                            HttpClient httpClient = new DefaultHttpClient();
                            httpGet.addHeader("requestType", "download");
                            httpGet.addHeader("fileName", fileName);
                            HttpResponse httpResponse = httpClient.execute(httpGet);

                            HttpEntity entity = httpResponse.getEntity();
                            InputStream in = entity.getContent();
                            String localFile = getFilesDir().getAbsolutePath();
                            File file = new File(localFile + "/" + fileName + ".mp4");

                            if (!file.exists()) {
                                file.createNewFile();
                            }

                            OutputStream out = new FileOutputStream(file);
                            byte[] buffer = new byte[1024 * 1024 * 10];
                            int readLength = 0;
                            while ((readLength = in.read(buffer)) > 0) {
                                byte[] bytes = new byte[readLength];
                                System.arraycopy(buffer, 0, bytes, 0, readLength);
                                out.write(bytes);
                            }
                            out.flush();

                            Message msg = new Message();
                            msg.what = COMPLETED;
                            uri = Uri.parse(localFile + "/" + fileName + ".mp4");
                            handler.sendMessage(msg);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
                break;
            case R.id.button_dialog_call:
                dialog.dismiss();
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phoneView.getText()));
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                break;
            case R.id.button_dialog_message:
                dialog.dismiss();
                Intent intent2 = new Intent();
                // 系统默认的action，用来打开默认的短信界面
                intent2.setAction(Intent.ACTION_SENDTO);
                // 需要发短信的号码
                intent2.setData(Uri.parse("smsto:" + phoneView.getText()));
                startActivity(intent2);
                break;
            case R.id.button_dialog_cancel:
                dialog.dismiss();
                break;
            case R.id.img_back:
                Intent intent3 = new Intent(JohnnyCourseInfo.this, JohnnyMainActivity.class);
                intent3.putExtra("flag", 1);
                startActivity(intent3);
                finish();
                break;
        }
    }
}