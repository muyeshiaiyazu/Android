package johnny;

import android.content.Intent;
import android.os.Bundle;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.phw.fitnessclubsystem.R;
import connect.ServerUrl;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class JohnnyCourseAdd extends AppCompatActivity implements View.OnClickListener {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.johnny_add_course);
        View decorView = getWindow().getDecorView();
        int option = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(option);
        Button addCourse = (Button) findViewById(R.id.button_add_course);
        ImageView back = (ImageView) findViewById(R.id.img_back);
        addCourse.setOnClickListener(this);          //触发事件
        back.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button_add_course:
                new Thread(new Runnable() {
                    EditText courseName = findViewById(R.id.edit_course_name);
                    EditText courseJohnny = findViewById(R.id.edit_instructor_name);
                    EditText courseJohnnyPhone = findViewById(R.id.edit_course_phone);
                    EditText courseTime = findViewById(R.id.edit_course_time);
                    EditText coursePrice = findViewById(R.id.edit_course_pay);
                    EditText courseContent = findViewById(R.id.edit_course_content);
                    @Override
                    public void run() {
                        try {
                            URL url  = ServerUrl.getServerUrl();
                            HttpURLConnection http = (HttpURLConnection) url.openConnection();  //实例化连接对象
                            http.setDoInput(true);  //可读可写
                            http.setDoOutput(true);
                            http.setUseCaches(false);  //不允许使用缓存
                            http.setRequestMethod("POST");  //设置传输方式为 post
                            http.connect();  //创建连接

                            JSONObject newCourse = new JSONObject();
                            newCourse.put("requestType", "addCourse");
                            newCourse.put("courseName", courseName.getText().toString());
                            newCourse.put("courseJohnny", courseJohnny.getText().toString());
                            newCourse.put("courseJohnnyPhone", courseJohnnyPhone.getText().toString());
                            newCourse.put("courseContent", courseContent.getText().toString());
                            newCourse.put("courseTime", courseTime.getText().toString());
                            newCourse.put("coursePrice", coursePrice.getText().toString());

                            //向服务端发送新建课程的JSON对象
                            OutputStream os = http.getOutputStream();
                            OutputStreamWriter osw = new OutputStreamWriter(os,"UTF-8");
                            BufferedWriter bw = new BufferedWriter(osw);
                            bw.write(newCourse.toString());
                            bw.flush();

                            //获取web 端返回的数据
                            InputStream is = http.getInputStream();
                            InputStreamReader isr = new InputStreamReader(is,"UTF-8");
                            BufferedReader br = new BufferedReader(isr);
                            JSONObject response = new JSONObject(br.readLine());
                            if (response.getString("response").equals("successful")) {
                                Looper.prepare();
                                Toast.makeText(JohnnyCourseAdd.this, "新建成功!", Toast.LENGTH_LONG).show();
                                Looper.loop();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
                break;
            case R.id.img_back:
                Intent intent = new Intent(JohnnyCourseAdd.this, JohnnyMainActivity.class);
                intent.putExtra("flag", 2);
                startActivity(intent);
                finish();
                break;
        }
    }
}
