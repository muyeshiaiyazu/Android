package johnny;

import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import com.example.phw.fitnessclubsystem.R;

import org.json.JSONArray;
import org.json.JSONObject;

import connect.ServerUrl;
import object.*;

public class JohnnyNews extends Fragment {
    private JohnnyNewsAdapter adapter = null;
    private List list;
    private ListView listView;
    private boolean getCompleted;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        list = new ArrayList<News>();
        getCompleted = false;
        Classinit();
        while(!getCompleted);
        View view = inflater.inflate(R.layout.news_list, container, false);
        listView = (ListView) view.findViewById(R.id.list_news);
        adapter = new JohnnyNewsAdapter(getActivity(), R.layout.news_list_item, list);
        listView.setAdapter(adapter);
        return view;
    }

    public void Classinit() {//后续在这个函数里改变初始值
        if(!ServerUrl.isNetworkAvailable(getContext())){
            Cursor cursor = getContext().getContentResolver().query(Uri.parse("content://myprovider/table_news"), new String[]{"title","time","content"}, null, null, null);
            if(cursor.moveToFirst()){
                do{
                    list.add(new News(R.mipmap.head,cursor.getString(0), cursor.getString(1),cursor.getString(2)));
                } while(cursor.moveToNext());
            }
            cursor.close();
            getCompleted = true;
        }else {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        URL url = ServerUrl.getServerUrl();
                        HttpURLConnection http = (HttpURLConnection) url.openConnection();  //实例化连接对象
                        http.setDoInput(true);  //可读可写
                        http.setDoOutput(true);
                        http.setUseCaches(false);  //不允许使用缓存
                        http.setRequestMethod("POST");  //设置传输方式为 post
                        http.connect();  //创建连接

                        JSONObject getNews = new JSONObject();
                        getNews.put("requestType", "getNews");

                        //向服务端发送同步课程的JSON对象
                        OutputStream os = http.getOutputStream();
                        OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8");
                        BufferedWriter bw = new BufferedWriter(osw);
                        bw.write(getNews.toString());
                        bw.flush();

                        //获取web 端返回的数据
                        InputStream is = http.getInputStream();
                        InputStreamReader isr = new InputStreamReader(is, "UTF-8");
                        BufferedReader br = new BufferedReader(isr);

                        JSONArray news = new JSONArray(br.readLine());

                        for (int i = 0; i < news.length(); i++) {
                            JSONObject news1 = (JSONObject) news.get(i);
                            News n = new News(R.mipmap.head
                                    , news1.getString("newsTitle")
                                    , news1.getString("newsTime")
                                    , news1.getString("newsContent"));
                            list.add(n);
                        }
                        getCompleted = true;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        }
    }
}

