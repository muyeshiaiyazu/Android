package johnny;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import object.*;
import com.example.phw.fitnessclubsystem.R;

public class JohnnyNewsInfo extends AppCompatActivity implements View.OnClickListener {
    private News news;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.news_info);
        View decorView = getWindow().getDecorView();
        int option = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(option);

        news = (News)getIntent().getSerializableExtra("news");

        ImageView back = (ImageView) findViewById(R.id.img_back);
        TextView title = (TextView) findViewById(R.id.text_title);
        TextView content = (TextView) findViewById(R.id.text_content);

        title.setText(news.getTitle());
        content.setText(news.getContent());
        back.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent(JohnnyNewsInfo.this, JohnnyMainActivity.class);
        intent.putExtra("flag", 0);
        startActivity(intent);
        finish();
    }
}