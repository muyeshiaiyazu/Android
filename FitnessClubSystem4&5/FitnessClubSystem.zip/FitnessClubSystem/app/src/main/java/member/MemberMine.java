package member;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.phw.fitnessclubsystem.R;

import object.User;

public class MemberMine extends Fragment{
    View view;
    User user;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        user = (User)getArguments().getSerializable("user");
        view = inflater.inflate(R.layout.member_mine, container, false);

        TextView userName = (TextView)view.findViewById(R.id.text_true_name);
        TextView sex = (TextView)view.findViewById(R.id.text_true_sex);
        TextView phone = (TextView)view.findViewById(R.id.text_true_phone);
        TextView intro = (TextView)view.findViewById(R.id.text_true_info);

        userName.setText(user.getUserName());
        sex.setText(user.getSex());
        phone.setText(user.getPhone());
        intro.setText(user.getIntro());
        
        return view;
    }
}
