package member;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.List;

import com.example.phw.fitnessclubsystem.R;
import object.*;

public class MemberCourseAdapter extends ArrayAdapter{
    private int resource;
    public MemberCourseAdapter(Context context, int resource, List objects) {
        super(context, resource, objects);
        // TODO Auto-generated constructor stub
        this.resource = resource;//resource为listView的每个子项的布局id
    }

    //getView为listView的每个子项的布局设置内容
    //convertView用于将之前加载好的布局进行缓存
    //设置一个viewHolder对控件进行缓存
    @Override
    public View getView(int position, final View convertView, ViewGroup parent) {
        View view;
        ViewHolder viewHolder;
        final Course course = (Course) getItem(position);//获得实例
        if (convertView == null) {
            view = LayoutInflater.from(getContext()).inflate(resource, null);
            viewHolder = new ViewHolder();
            viewHolder.courseImage = (ImageView) view.findViewById(R.id.img_member_course);
            viewHolder.courseName = (TextView) view.findViewById(R.id.text_course_title);
            viewHolder.coursePrice = (TextView) view.findViewById(R.id.text_course_payment);
            viewHolder.courseRead = (ImageView) view.findViewById(R.id.img_course_read);
            view.setTag(viewHolder);
            viewHolder.courseImage.setImageResource(course.getImgSrc());
            viewHolder.courseName.setText(course.getName());
            viewHolder.coursePrice.setText(course.getPrice());
            viewHolder.courseRead.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {                        // TODO Auto-generated method stub
                    //进入课程详细信息界面
                    Intent intent = new Intent(getContext(), MemberCourseInfo.class);
                    intent.putExtra("course",course);
                    getContext().startActivity(intent);
                    Activity activity = (Activity)getContext();
                }
            });
        } else {
            view = convertView;
            viewHolder = (ViewHolder) view.getTag();
        }
        return view;
    }

    class ViewHolder {
        ImageView courseImage;
        TextView courseName;
        ImageView courseRead;
        TextView coursePrice;
    }
}
