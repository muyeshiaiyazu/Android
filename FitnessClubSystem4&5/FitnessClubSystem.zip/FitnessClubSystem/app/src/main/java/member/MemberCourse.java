package member;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import connect.ServerUrl;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import com.example.phw.fitnessclubsystem.R;
import object.*;

public class MemberCourse extends Fragment {
    private MemberCourseAdapter adapter = null;
    private List list;
    private ListView listView;
    private boolean getCompleted;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        list = new ArrayList<Course>();
        getCompleted = false;
        Classinit();
        while(!getCompleted);
        View view = inflater.inflate(R.layout.member_course, container, false);
        listView = (ListView) view.findViewById(R.id.list_course);
        adapter = new MemberCourseAdapter(getActivity(), R.layout.course_list_item, list);
        listView.setAdapter(adapter);
        return view;
    }

    public void Classinit() {//后续在这个函数里改变初始值
        if(!ServerUrl.isNetworkAvailable(getContext())){
            Cursor cursor = getContext().getContentResolver().query(Uri.parse("content://myprovider/table_course")
                    , new String[]{"course_name","johnny_name","johnny_phone","course_content","course_time","course_price"}
                    , null, null, null);
            if(cursor.moveToFirst()){
                do{
                    list.add(new Course(
                            R.mipmap.head
                            ,cursor.getString(0)
                            , cursor.getString(1)
                            ,cursor.getString(2)
                            ,cursor.getString(3)
                            ,cursor.getString(4)
                            ,cursor.getString(5)));
                } while(cursor.moveToNext());
            }
            cursor.close();
            getCompleted = true;
        }else {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        URL url = ServerUrl.getServerUrl();
                        HttpURLConnection http = (HttpURLConnection) url.openConnection();  //实例化连接对象
                        http.setDoInput(true);  //可读可写
                        http.setDoOutput(true);
                        http.setUseCaches(false);  //不允许使用缓存
                        http.setRequestMethod("POST");  //设置传输方式为 post
                        http.connect();  //创建连接

                        JSONObject getCourse = new JSONObject();
                        getCourse.put("requestType", "getCourse");

                        //向服务端发送同步课程的JSON对象
                        OutputStream os = http.getOutputStream();
                        OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8");
                        BufferedWriter bw = new BufferedWriter(osw);
                        bw.write(getCourse.toString());
                        bw.flush();

                        //获取web 端返回的数据
                        InputStream is = http.getInputStream();
                        InputStreamReader isr = new InputStreamReader(is, "UTF-8");
                        BufferedReader br = new BufferedReader(isr);

                        JSONArray courses = new JSONArray(br.readLine());

                        for (int i = 0; i < courses.length(); i++) {
                            JSONObject course = (JSONObject) courses.get(i);
                            Course c = new Course(R.mipmap.head
                                    , course.getString("courseName")
                                    , course.getString("courseJohnny")
                                    , course.getString("courseJohnnyPhone")
                                    , course.getString("courseTime")
                                    , course.getString("coursePrice")
                                    , course.getString("courseContent"));
                            list.add(c);
                        }
                        getCompleted = true;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        }
    }
}
