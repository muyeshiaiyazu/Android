package appMainClass;

import android.os.Bundle;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.phw.fitnessclubsystem.R;
import connect.ServerUrl;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Register extends AppCompatActivity implements View.OnClickListener{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
        View decorView = getWindow().getDecorView();
        int option = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(option);
        Spinner registerStatus = (Spinner) findViewById ( R.id.register_spinner_status);
        List<String> list = new ArrayList<String>();
        list.add("Johnny");
        list.add("Member");
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,list);
        registerStatus.setAdapter(adapter);
        Button registerButton = (Button) findViewById ( R.id.register_button_sure);
        registerButton.setOnClickListener(this);          //触发事件
    }
    @Override
    public void onClick(View v) {
        new Thread(new Runnable() {
            EditText userNameEdit = (EditText) findViewById(R.id.register_edit_name);
            EditText passwordEdit = (EditText) findViewById(R.id.register_edit_password);
            EditText surePasswordEdit = (EditText) findViewById(R.id.register_edit_surepassword);
            Spinner statusEdit = (Spinner) findViewById(R.id.register_spinner_status);
            String userName = userNameEdit.getText().toString();
            String password = passwordEdit.getText().toString();
            String surePassword = surePasswordEdit.getText().toString();
            String status = (String) statusEdit.getSelectedItem();
            @Override
            public void run() {
                if (!password.equals(surePassword)) {
                    Looper.prepare();
                    Toast.makeText(Register.this, "两次输入的密码不一致!", Toast.LENGTH_LONG).show();
                    Looper.loop();
                } else {
                    try{
                        URL url  = ServerUrl.getServerUrl();
                        HttpURLConnection http = (HttpURLConnection) url.openConnection();  //实例化连接对象
                        http.setDoInput(true);  //可读可写
                        http.setDoOutput(true);
                        http.setUseCaches(false);  //不允许使用缓存
                        http.setRequestMethod("POST");  //设置传输方式为 post
                        http.connect();  //创建连接

                        JSONObject userInfo = new JSONObject();
                        userInfo.put("requestType","register");
                        userInfo.put("userName",userName);
                        userInfo.put("password",password);
                        userInfo.put("status",status);

                        //向服务端发送注册请求的JSON对象
                        OutputStream os = http.getOutputStream();
                        OutputStreamWriter osw = new OutputStreamWriter(os);
                        BufferedWriter bw = new BufferedWriter(osw);
                        bw.write(userInfo.toString());
                        bw.flush();

                        //获取web 端返回的数据
                        InputStream is = http.getInputStream();
                        InputStreamReader isr = new InputStreamReader(is);
                        BufferedReader br = new BufferedReader(isr);
                        JSONObject response = new JSONObject(br.readLine());
                        if (response.getString("response").equals("successful")) {
                            Looper.prepare();
                            Toast.makeText(Register.this, "注册成功!", Toast.LENGTH_LONG).show();
                            Looper.loop();
                        } else if(response.getString("response").equals("failed")){
                            Looper.prepare();
                            Toast.makeText(Register.this, "用户名已被占用!", Toast.LENGTH_LONG).show();
                            Looper.loop();
                        }
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                }
            }
        }).start();
    }
}
