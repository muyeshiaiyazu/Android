package appMainClass;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.PagerSnapHelper;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.os.Looper;

import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import externalClass.BannerAdapter;
import externalClass.BannerIndicator;
import externalClass.SmoothLinearLayoutManager;
import johnny.JohnnyMainActivity;
import member.MemberMainActivity;
import com.example.phw.fitnessclubsystem.R;
import com.tencent.connect.UserInfo;
import com.tencent.connect.auth.QQToken;
import com.tencent.connect.common.Constants;
import com.tencent.tauth.IUiListener;
import com.tencent.tauth.Tencent;
import com.tencent.tauth.UiError;

import connect.ServerUrl;
import object.*;

public class Login extends AppCompatActivity implements View.OnClickListener{
    private List<Integer> list = new ArrayList<>(4);
    private Tencent mTencent;
    String token;
    String expires_in;
    String uniqueCode;
    //授权登录监听（最下面是返回结果）
    private IUiListener loginListener = new IUiListener() {
        @Override
        public void onComplete(Object o) {
            uniqueCode = ((JSONObject) o).optString("openid"); //QQ的openid
            try {
                token = ((JSONObject) o).getString("access_token");
                expires_in = ((JSONObject) o).getString("expires_in");
            } catch (JSONException e) {
                e.printStackTrace();
            }
                //在这里直接可以处理登录
                QQToken qqtoken = mTencent.getQQToken();
                mTencent.setOpenId(uniqueCode);
                mTencent.setAccessToken(token, expires_in);
                UserInfo info = new UserInfo(getApplicationContext(), qqtoken);
                info.getUserInfo(new IUiListener() {
                    @Override
                    public void onComplete(Object o) {
                        JSONObject jo = (JSONObject) o;
//                        System.out.println("用户信息:"+jo.toString());
                        String nickName = jo.optString("nickname");
                        String sex = jo.optString("gender");
                        User user = new User(nickName,
                                null,
                                "member",
                                sex,
                                null,
                                "安卓 QQ用户");
                        Intent intent2 = new Intent(Login.this, MemberMainActivity.class);
                        intent2.putExtra("user", user);
                        startActivity(intent2);
                        finish();
                    }

                    @Override
                    public void onError(UiError uiError) {
                    }

                    @Override
                    public void onCancel() {
                    }
                });
        }

        @Override
        public void onError(UiError uiError) {
        }

        @Override
        public void onCancel() {
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        View decorView = getWindow().getDecorView();
        int option = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(option);

        list.add(R.mipmap.fitness1);
        list.add(R.mipmap.fitness2);
        list.add(R.mipmap.fitness3);
        list.add(R.mipmap.fitness4);

        BannerAdapter adapter = new BannerAdapter(this, list);
        final RecyclerView recyclerView = findViewById(R.id.recycler);
        final SmoothLinearLayoutManager layoutManager = new SmoothLinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);

        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(adapter);
        recyclerView.scrollToPosition(list.size() * 10);

        PagerSnapHelper snapHelper = new PagerSnapHelper();
        snapHelper.attachToRecyclerView(recyclerView);

        final BannerIndicator bannerIndicator = findViewById(R.id.indicator);
        bannerIndicator.setNumber(list.size());

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                if (newState == RecyclerView.SCROLL_STATE_IDLE) {
                    int i = layoutManager.findFirstVisibleItemPosition() % list.size();
                    bannerIndicator.setPosition(i);
                }
            }
        });

        ScheduledExecutorService scheduledExecutorService = Executors.newScheduledThreadPool(1);
        scheduledExecutorService.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                recyclerView.smoothScrollToPosition(layoutManager.findFirstVisibleItemPosition() + 1);
            }
        }, 2000, 2000, TimeUnit.MILLISECONDS);

        Button loginButton = (Button) findViewById ( R.id.login_button_sure);
        loginButton.setOnClickListener(this);          //触发事件

        //QQ第三方登录;
        Button  QQlogin = (Button) findViewById(R.id.login_button_tencent);
        QQlogin.setOnClickListener(this);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        mTencent.onActivityResultData(requestCode, resultCode, data, loginListener);
        if (requestCode == Constants.REQUEST_API) {
            if (resultCode == Constants.REQUEST_QQ_SHARE ||
                    resultCode == Constants.REQUEST_QZONE_SHARE ||
                    resultCode == Constants.REQUEST_OLD_SHARE) {
                    mTencent.handleResultData(data, loginListener);
            }
        }
    }

    @Override
    public void onClick(View v){
        switch(v.getId()){
            case R.id.login_button_sure:
                new Thread(new Runnable() {
                    EditText userNameEdit = (EditText) findViewById ( R.id.login_edit_name);
                    EditText passwordEdit = (EditText) findViewById ( R.id.login_edit_password);
                    String userName = userNameEdit.getText().toString();
                    String password = passwordEdit.getText().toString();
                    @Override
                    public void run() {
                        try{
                            if(userName.equals("")){
                                Looper.prepare();
                                Toast.makeText(Login.this, "请输入用户名！", Toast.LENGTH_LONG).show();
                                Looper.loop();
                            }else if(password.equals("")){
                                Looper.prepare();
                                Toast.makeText(Login.this, "请输入密码！", Toast.LENGTH_LONG).show();
                                Looper.loop();
                            }else{
                                URL url  = ServerUrl.getServerUrl();
                                HttpURLConnection http = (HttpURLConnection) url.openConnection();  //实例化连接对象
                                http.setDoInput(true);  //可读可写
                                http.setDoOutput(true);
                                http.setUseCaches(false);  //不允许使用缓存
                                http.setRequestMethod("POST");  //设置传输方式为 post
                                http.connect();  //创建连接

                                JSONObject userInfo = new JSONObject();
                                userInfo.put("requestType","login");
                                userInfo.put("userName",userName);
                                userInfo.put("password",password);

                                //向服务端发送登录请求的JSON对象
                                OutputStream os = http.getOutputStream();
                                OutputStreamWriter osw = new OutputStreamWriter(os);
                                BufferedWriter bw = new BufferedWriter(osw);
                                bw.write(userInfo.toString());
                                bw.flush();

                                //获取web 端返回的数据
                                InputStream is = http.getInputStream();
                                InputStreamReader isr = new InputStreamReader(is);
                                BufferedReader br = new BufferedReader(isr);
                                JSONObject response = new JSONObject(br.readLine());

                                //判断结果
                                if(response.getString("status").equals("Johnny")){
                                    User user = new User(response.getString("userName"),
                                            response.getString("password"),
                                            response.getString("status"),
                                            response.getString("sex"),
                                            response.getString("phone"),
                                            response.getString("intro"));

                                    String localFile = getFilesDir().getAbsolutePath();
                                    File file = new File(localFile + "/currentUser.txt");
                                    if (!file.exists()) {
                                        file.createNewFile();
                                    }else{
                                        file.delete();
                                        (new File(localFile + "/currentUser.txt")).createNewFile();
                                    }
                                    RandomAccessFile raf = new RandomAccessFile(localFile + "/currentUser.txt","rw");
                                    raf.writeUTF(user.getUserName());
                                    raf.writeUTF(user.getPassword());
                                    raf.writeUTF(user.getStatus());
                                    raf.writeUTF(user.getSex());
                                    raf.writeUTF(user.getPhone());
                                    raf.writeUTF(user.getIntro());

                                    Looper.prepare();
                                    Toast.makeText(Login.this, "教练登陆成功！", Toast.LENGTH_LONG).show();
                                    Intent intent = new Intent(Login.this, JohnnyMainActivity.class);
                                    intent.putExtra("user", user);
                                    startActivity(intent);
                                    finish();
                                    Looper.loop();
                                } else if(response.getString("status").equals("Member")) {
                                    User user = new User(response.getString("userName"),
                                            response.getString("password"),
                                            response.getString("status"),
                                            response.getString("sex"),
                                            response.getString("phone"),
                                            response.getString("intro"));

                                    String localFile = getFilesDir().getAbsolutePath();
                                    File file = new File(localFile + "/currentUser.txt");
                                    if (!file.exists()) {
                                        file.createNewFile();
                                    }else{
                                        file.delete();
                                        (new File(localFile + "/currentUser.txt")).createNewFile();
                                    }
                                    RandomAccessFile raf = new RandomAccessFile(localFile + "/currentUser.txt","rw");
                                    raf.writeUTF(user.getUserName());
                                    raf.writeUTF(user.getPassword());
                                    raf.writeUTF(user.getStatus());
                                    raf.writeUTF(user.getSex());
                                    raf.writeUTF(user.getPhone());
                                    raf.writeUTF(user.getIntro());

                                    Looper.prepare();
                                    Toast.makeText(Login.this, "学员登陆成功！", Toast.LENGTH_LONG).show();
                                    Intent intent2 = new Intent(Login.this, MemberMainActivity.class);
                                    intent2.putExtra("user", user);
                                    startActivity(intent2);
                                    finish();
                                    Looper.loop();
                                } else if(response.getString("status").equals("failed")){
                                    Looper.prepare();
                                    Toast.makeText(Login.this, "用户名或密码错误！", Toast.LENGTH_LONG).show();
                                    Looper.loop();
                                }
                            }
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                }).start();
                break;
            case R.id.login_button_tencent:
                mTencent = Tencent.createInstance("101533537", this.getApplicationContext());
                mTencent.login(this, "all", loginListener);
                break;
        }
    }
}
