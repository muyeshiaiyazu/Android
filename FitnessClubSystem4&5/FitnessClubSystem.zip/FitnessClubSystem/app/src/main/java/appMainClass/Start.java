package appMainClass;

import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.strictmode.IntentReceiverLeakedViolation;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import connect.*;
import johnny.JohnnyMainActivity;
import member.MemberCourseInfo;
import object.*;
import member.MemberMainActivity;

import com.example.phw.fitnessclubsystem.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.CountDownLatch;

public class Start extends AppCompatActivity implements View.OnClickListener {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.start);
        View decorView = getWindow().getDecorView();
        int option = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(option);
        //检查网络连接
        if (!ServerUrl.isNetworkAvailable(this)) {
            //进入最近登录未注销用户的界面
            Toast.makeText(Start.this, "无网络连接!", Toast.LENGTH_LONG).show();
            try {
                String localFile = getFilesDir().getAbsolutePath();
                RandomAccessFile raf = new RandomAccessFile(localFile + "/currentUser.txt", "rw");
                User user = new User(raf.readUTF(),
                        raf.readUTF(),
                        raf.readUTF(),
                        raf.readUTF(),
                        raf.readUTF(),
                        raf.readUTF());

                if (user.getStatus().equals("Johnny")) {
                    Intent it = new Intent(Start.this, JohnnyMainActivity.class);
                    it.putExtra("user", user);
                    startActivity(it);
                } else {
                    Intent it = new Intent(Start.this, MemberMainActivity.class);
                    it.putExtra("user", user);
                    startActivity(it);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            final CountDownLatch countDownLatch1 = new CountDownLatch(1);
            final CountDownLatch countDownLatch2 = new CountDownLatch(1);
            Toast.makeText(Start.this, "同步服务器数据中...", Toast.LENGTH_LONG).show();
            try {
                //更新本地数据库的文章信息
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            URL url = ServerUrl.getServerUrl();
                            HttpURLConnection http = (HttpURLConnection) url.openConnection();  //实例化连接对象
                            http.setDoInput(true);  //可读可写
                            http.setDoOutput(true);
                            http.setUseCaches(false);  //不允许使用缓存
                            http.setRequestMethod("POST");  //设置传输方式为 post
                            http.connect();  //创建连接

                            JSONObject getCourse = new JSONObject();
                            getCourse.put("requestType", "getNews");

                            //向服务端发送同步课程的JSON对象
                            OutputStream os = http.getOutputStream();
                            OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8");
                            BufferedWriter bw = new BufferedWriter(osw);
                            bw.write(getCourse.toString());
                            bw.flush();

                            //获取web 端返回的数据
                            InputStream is = http.getInputStream();
                            InputStreamReader isr = new InputStreamReader(is, "UTF-8");
                            BufferedReader br = new BufferedReader(isr);

                            JSONArray news = new JSONArray(br.readLine());


                            for (int i = 0; i < news.length(); i++) {
                                JSONObject news1 = (JSONObject) news.get(i);
                                ContentValues newsValues = new ContentValues();
                                newsValues.put("title", news1.getString("newsTitle"));
                                newsValues.put("time", news1.getString("newsTime"));
                                newsValues.put("content", news1.getString("newsContent"));
                                getContentResolver().insert(Uri.parse("content://myprovider/table_news"), newsValues);
                            }
                            countDownLatch1.countDown();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                }).start();
                countDownLatch1.await();
                //更新本地数据库的课程信息，其中包含教练的私人信息
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            URL url = ServerUrl.getServerUrl();
                            HttpURLConnection http = (HttpURLConnection) url.openConnection();  //实例化连接对象
                            http.setDoInput(true);  //可读可写
                            http.setDoOutput(true);
                            http.setUseCaches(false);  //不允许使用缓存
                            http.setRequestMethod("POST");  //设置传输方式为 post
                            http.connect();  //创建连接

                            JSONObject getCourse = new JSONObject();
                            getCourse.put("requestType", "getCourse");

                            //向服务端发送同步课程的JSON对象
                            OutputStream os = http.getOutputStream();
                            OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8");
                            BufferedWriter bw = new BufferedWriter(osw);
                            bw.write(getCourse.toString());
                            bw.flush();

                            //获取web 端返回的数据
                            InputStream is = http.getInputStream();
                            InputStreamReader isr = new InputStreamReader(is, "UTF-8");
                            BufferedReader br = new BufferedReader(isr);

                            JSONArray courses = new JSONArray(br.readLine());

                            for (int i = 0; i < courses.length(); i++) {
                                JSONObject course = (JSONObject) courses.get(i);
                                ContentValues courseValues = new ContentValues();
                                courseValues.put("course_name", course.getString("courseName"));
                                courseValues.put("johnny_name", course.getString("courseJohnny"));
                                courseValues.put("johnny_phone", course.getString("courseJohnnyPhone"));
                                courseValues.put("course_content", course.getString("courseContent"));
                                courseValues.put("course_time", course.getString("courseTime"));
                                courseValues.put("course_price", course.getString("coursePrice"));
                                getContentResolver().insert(Uri.parse("content://myprovider/table_course"), courseValues);
                            }
                            countDownLatch2.countDown();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                }).start();
                countDownLatch2.await();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            Button loginButton = (Button) findViewById(R.id.start_button_login);
            loginButton.setOnClickListener(this);          //触发事件
            Button registerButton = (Button) findViewById(R.id.start_button_register);
            registerButton.setOnClickListener(this);          //触发事件
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.start_button_login:
                Intent intent = new Intent(Start.this, Login.class);
                startActivity(intent);
                break;
            case R.id.start_button_register:
                Intent intent2 = new Intent(Start.this, Register.class);
                startActivity(intent2);
                break;
        }
    }
}
