package object;

import java.io.Serializable;

public class News implements Serializable {
    int ImgSrc;
    String Title;
    String Content;
    String Time;
    public News(int imgSrc, String title, String time, String content){
        this.ImgSrc = imgSrc;
        this.Title = title;
        this.Content = content;
        this.Time = time;
    }
    public int getImgSrc() {
        return ImgSrc;
    }
    public String getTitle() { return Title; }
    public String getContent() {
        return Content;
    }
    public String getTime() {
        return Time;
    }
    public void setTitle(String title) {
        this.Title = title;
    }
    public void setContent(String content) {
        this.Content = content;
    }
    public void setTime(String time) {
        this.Time = time;
    }
    public void setImgSrc(int imgsrc) {
        this.ImgSrc = imgsrc;
    }
}
