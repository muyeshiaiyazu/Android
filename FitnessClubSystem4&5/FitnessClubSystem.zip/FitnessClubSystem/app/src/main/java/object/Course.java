package object;

import java.io.Serializable;

public class Course implements Serializable {
    int ImgSrc;//课程预览图

    String Name;//
    String Johnny;//教练名字
    String JohnnyPhone;//教练电话
    String Time;//上课时间
    String Price;//教练可以设置这个值，学员可以看到价格并支付，支付后才能上课
    String Content;

    public Course(){}

    public Course(int imgsrc, String name, String johnny, String johnnyPhone, String content, String time, String price){
        this.ImgSrc = imgsrc;
        this.Name = name;
        this.Johnny = johnny;
        this.JohnnyPhone = johnnyPhone;
        this.Time = time;
        this.Price = price;
        this.Content = content;
    }

    public int getImgSrc() { return ImgSrc; }
    public String getName() { return Name; }
    public String getJohnny() { return Johnny; }
    public String getJohnnyPhone() { return JohnnyPhone; }
    public String getTime() {
        return Time;
    }
    public String getPrice() { return Price; }
    public String getContent() { return Content; }

    public void setImgSrc(int imgsrc) { this.ImgSrc = imgsrc; }
    public void setName(String name) { this.Name = name; }
    public void setJohnny(String johnny) { this.Johnny = johnny; }
    public void setJohnnyPhone(String johnnyPhone) { this.JohnnyPhone = johnnyPhone; }
    public void setTime(String time) { this.Time = time; }
    public void setPrice(String price) { this.Price = price; }
    public void setContent(String content) { this.Content = content; }
}
