package object;

import java.io.Serializable;

public class User implements Serializable {
    private String userName;
    private String password;
    private String status;
    private String sex;
    private String phone;
    private String intro;

    public User(){ }

    public User(String userName, String password, String status, String sex, String phone, String intro){
        this.userName = userName;
        this.password = password;
        this.status = status;
        this.sex = sex;
        this.phone = phone;
        this.intro = intro;
    }

    public String getUserName() {
        return this.userName;
    }
    public String getStatus() { return this.status; }
    public String getSex() {
        return this.sex;
    }
    public String getPhone() {
        return this.phone;
    }
    public String getIntro(){ return this.intro; }
    public String getPassword(){return password;}

    public void setUserName(String userName) {
        this.userName = userName;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public void setStatus(String status) { this.status = status; }
    public void setSex(String sex) {
        this.sex = sex;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public void setIntro(String intro){ this.intro = intro; }
}
