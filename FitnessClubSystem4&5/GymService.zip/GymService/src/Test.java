
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;

import org.json.JSONArray;
import org.json.JSONObject;


@WebServlet(name = "/Test")
public class Test extends HttpServlet {
    private File file;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");  //设置编码方式
        response.setCharacterEncoding("utf-8");
        String isDownload = request.getHeader("requestType");

        if (isDownload.equals("download")) {
            int BUFFER_SIZE = 1024 * 1024 * 10;
            String downloadUrl = "C:\\Users\\phw\\GymService\\gymVideos\\";

            request.setCharacterEncoding("utf-8");
            response.setCharacterEncoding("utf-8");
            response.setContentType("application/octet-stream");

            String fileName = request.getHeader("fileName");


            //可以根据传递来的userName和passwd做进一步处理，比如验证请求是否合法等
            File file = new File(downloadUrl + "a.txt");
            switch (fileName) {
                case "1":
                    file = new File(downloadUrl + "1.mp4");
                    break;
                case "2":
                    file = new File(downloadUrl + "2.mp4");
                    break;
                case "3":
                    file = new File(downloadUrl + "3.mp4");
                    break;
                case "4":
                    file = new File(downloadUrl + "4.mp4");
                    break;
                case "5":
                    file = new File(downloadUrl + "5.mp4");
                    break;
                case "6":
                    file = new File(downloadUrl + "6.mp4");
                    break;
            }
            response.setContentLength((int) file.length());
            response.setHeader("Accept-Ranges", "bytes");

            int readLength = 0;

            InputStream in = new BufferedInputStream(new FileInputStream(file), BUFFER_SIZE);
            OutputStream os = new BufferedOutputStream(response.getOutputStream());

            byte[] buffer = new byte[BUFFER_SIZE];
            while ((readLength = in.read(buffer)) > 0) {
                byte[] bytes = new byte[readLength];
                System.arraycopy(buffer, 0, bytes, 0, readLength);
                os.write(bytes);
            }
            os.flush();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");  //设置编码方式
        response.setCharacterEncoding("utf-8");

        InputStream is = request.getInputStream();
        InputStreamReader isr = new InputStreamReader(is, "utf-8");
        BufferedReader br = new BufferedReader(isr);
        JSONObject userJson = new JSONObject(br.readLine());
        String requestType = userJson.getString("requestType");

        openFile(requestType);

        switch (requestType) {
            case "register":
                register(userJson, response, file);
                break;
            case "login":
                login(userJson, response, file);
                break;
            case "getCourse":
                getCourse(userJson, response, file);
                break;
            case "addCourse":
                addCourse(userJson, response, file);
                break;
            case "getNews":
                getNews(userJson, response, file);
                break;
        }
    }

    void openFile(String requestType) throws IOException {
        switch (requestType) {
            case "register":
            case "login":
                file = new File("userAccounts.txt");
                if (!file.exists()) {
                    file.createNewFile();
                }
                break;
            case "getCourse":
            case "addCourse":
                file = new File("courses.txt");
                if (!file.exists()) {
                    file.createNewFile();
                }
                break;
            case "getNews":
                file = new File("news.txt");
                if (!file.exists()) {
                    file.createNewFile();
                }
                break;
        }
    }

    void register(JSONObject userJson, HttpServletResponse response, File file) throws IOException {
        RandomAccessFile raf = new RandomAccessFile(file, "rw");
        System.out.println("注册操作");

        OutputStream out = response.getOutputStream();
        OutputStreamWriter osw = new OutputStreamWriter(out,"utf-8");
        BufferedWriter bw = new BufferedWriter(osw);

        String userName = userJson.getString("userName");
        String password = userJson.getString("password");
        String status = userJson.getString("status");

        JSONObject res = new JSONObject();

        if (file.length() > 0) {
            raf.seek(0);
            String currentUserName = raf.readUTF();
            raf.readUTF();
            raf.readUTF();
            boolean hasRepeated = false;
            while (currentUserName != null) {
                if (currentUserName.equals(userName)) {
                    hasRepeated = true;
                    break;
                }
                if (raf.getFilePointer() < raf.length()) {
                    currentUserName = raf.readUTF();
                    raf.readUTF();
                    raf.readUTF();
                } else {
                    break;
                }
            }
            if (hasRepeated) {
                res.put("response","failed");
            } else {
                raf.seek(raf.length());
                raf.writeUTF(userName);
                raf.writeUTF(password);
                raf.writeUTF(status);
                raf.writeUTF("编辑性别");
                raf.writeUTF("编辑电话");
                raf.writeUTF("编辑简介");
                res.put("response","successful");
            }
        } else {
            raf.seek(raf.length());
            raf.writeUTF(userName);
            raf.writeUTF(password);
            raf.writeUTF(status);
            raf.writeUTF("编辑性别");
            raf.writeUTF("编辑电话");
            raf.writeUTF("编辑简介");
            res.put("response","successful");
        }
        raf.close();

        bw.write(res.toString());
        bw.flush();
    }

    void login(JSONObject userJson, HttpServletResponse response, File file) throws IOException {
        RandomAccessFile raf = new RandomAccessFile(file, "rw");
        System.out.println("登录操作");

        OutputStream out = response.getOutputStream();
        OutputStreamWriter osw = new OutputStreamWriter(out,"utf-8");
        BufferedWriter bw = new BufferedWriter(osw);

        String userName = userJson.getString("userName");
        String password = userJson.getString("password");

        JSONObject res = new JSONObject();

        if (file.length() != 0) {
            raf.seek(0);
            String currentUserName = raf.readUTF();//用户名
            String currentPassword = raf.readUTF();//密码
            String currentStatus = raf.readUTF();//身份
            String currentSex = raf.readUTF();//性别
            String currentPhone = raf.readUTF();//电话
            String currentIntro = raf.readUTF();//简介
            while (currentUserName != null) {
                if (currentUserName.equals(userName) && currentPassword.equals(password)) {
                    res.put("userName",currentUserName);
                    res.put("password",currentPassword);
                    res.put("status",currentStatus);
                    res.put("sex",currentSex);
                    res.put("phone",currentPhone);
                    res.put("intro",currentIntro);

                    break;
                }
                if(raf.getFilePointer()>=(raf.length()-1)){
                    break;
                }
                currentUserName = raf.readUTF();
                currentPassword = raf.readUTF();
                currentStatus = raf.readUTF();
                currentSex = raf.readUTF();
                currentPhone = raf.readUTF();
                currentIntro = raf.readUTF();
            }
            raf.close();
        } else {
            res.put("status","failed");
        }

        bw.write(res.toString());
        bw.flush();
    }

    void getCourse(JSONObject userJson, HttpServletResponse response, File file) throws IOException {
        RandomAccessFile raf = new RandomAccessFile(file, "rw");
        System.out.println("同步课程");

        OutputStream out = response.getOutputStream();
        OutputStreamWriter osw = new OutputStreamWriter(out,"utf-8");
        BufferedWriter bw = new BufferedWriter(osw);

        JSONArray jsonArray = new JSONArray();

        if (file.length() != 0) {
            raf.seek(0);
            String courseName = raf.readUTF();//课程名
            String courseJohnny = raf.readUTF();//教练名
            String courseJohnnyPhone = raf.readUTF();//教练联系方式
            String courseTime = raf.readUTF();//时间
            String coursePrice = raf.readUTF();//价格
            String courseContent = raf.readUTF();//详细内容
            while (courseName != null) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("courseName", courseName);//写入对象数据
                jsonObject.put("courseJohnny", courseJohnny);
                jsonObject.put("courseJohnnyPhone", courseJohnnyPhone);
                jsonObject.put("courseTime", courseTime);
                jsonObject.put("coursePrice", coursePrice);
                jsonObject.put("courseContent", courseContent);
                jsonArray.put(jsonObject);

                if(raf.getFilePointer()>=(raf.length()-1)){
                    break;
                }

                courseName = raf.readUTF();
                courseJohnny = raf.readUTF();
                courseJohnnyPhone = raf.readUTF();
                courseTime = raf.readUTF();
                coursePrice = raf.readUTF();
                courseContent = raf.readUTF();
            }
            raf.close();
        }

        bw.write(jsonArray.toString());
        bw.flush();
    }

    void addCourse(JSONObject newCourse, HttpServletResponse response, File file) throws IOException {
        RandomAccessFile raf = new RandomAccessFile(file, "rw");
        System.out.println("新增课程");

        OutputStream out = response.getOutputStream();
        OutputStreamWriter osw = new OutputStreamWriter(out,"utf-8");
        BufferedWriter bw = new BufferedWriter(osw);

        JSONObject res = new JSONObject();

        String courseName = newCourse.getString("courseName");//课程名
        String courseJohnny = newCourse.getString("courseJohnny");//教练名
        String courseJohnnyPhone = newCourse.getString("courseJohnnyPhone");//教练联系方式
        String courseTime = newCourse.getString("courseTime");//时间
        String coursePrice = newCourse.getString("coursePrice");//价格
        String courseContent = newCourse.getString("courseContent");//详细内容

        raf.seek(raf.length());
        raf.writeUTF(courseName);
        raf.writeUTF(courseJohnny);
        raf.writeUTF(courseJohnnyPhone);
        raf.writeUTF(courseTime);
        raf.writeUTF(coursePrice);
        raf.writeUTF(courseContent);

        res.put("response","successful");

        bw.write(res.toString());
        bw.flush();
    }

    void getNews(JSONObject news, HttpServletResponse response, File file) throws IOException{
        RandomAccessFile raf = new RandomAccessFile(file, "rw");
        System.out.println("获取新闻");

        OutputStream out = response.getOutputStream();
        OutputStreamWriter osw = new OutputStreamWriter(out,"utf-8");
        BufferedWriter bw = new BufferedWriter(osw);

        JSONArray jsonArray = new JSONArray();

        if (file.length() != 0) {
            raf.seek(0);
            String newsTitle = raf.readUTF();//新闻标题
            String newsTime = raf.readUTF();//新闻发布时间
            String newsContent = raf.readUTF();//新闻内容

            while (newsTitle != null) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("newsTitle", newsTitle);//写入对象数据
                jsonObject.put("newsTime", newsTime);
                jsonObject.put("newsContent", newsContent);
                jsonArray.put(jsonObject);

                if(raf.getFilePointer()>=(raf.length()-1)){
                    break;
                }

                newsTitle = raf.readUTF();
                newsTime = raf.readUTF();
                newsContent = raf.readUTF();
            }
            raf.close();
        }

        bw.write(jsonArray.toString());
        bw.flush();
    }
}